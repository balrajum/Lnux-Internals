/*
Name: Balraju M
Description : Implement copy command 
 */


#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

void my_copy(int src_fd, int dest_fd) {
    char ch;
    while (read(src_fd, &ch, 1) > 0) {
        write(dest_fd, &ch, 1);
    }
}

int main(int argc, char *argv[]) {
    struct stat var;
    int count = 0, flag1 = 0;

    if (argc == 3 || argc == 4) {
        if (argc == 4) {
            int res = strcmp(argv[1], "-p");
            if (res != 0) {
                count = 1;
            } else {
                count = 2;
            }
        }

        if (count == 1) {
            printf("Invalid arguments\nPass args: ./a.out -p <srcfile> <destfile>\n");
            return 0;
        } else {
            int src_fd = open(argv[argc - 2], O_RDONLY);
            if (src_fd == -1) {
                printf("Source file is not present\n");
                return 0;
            }

            if (count == 2) {
                fstat(src_fd, &var);
                flag1 = 1;
            }

            int dest_fd = open(argv[argc - 1], O_RDONLY);
            if (dest_fd == -1) {
                // Destination file doesn't exist; create it
                if (flag1 == 0) {
                    dest_fd = open(argv[argc - 1], O_CREAT | O_WRONLY, 0765);
                } else {
                    dest_fd = open(argv[argc - 1], O_CREAT | O_WRONLY, var.st_mode);
                }
                my_copy(src_fd, dest_fd);
            } else {
                // Destination file exists
                char c;
                if (read(dest_fd, &c, 1) > 0) {
                    printf("Dest file is having some content. Do you want to overwrite? (y/n): ");
                    char opt;
                    scanf(" %c", &opt); 

                    if (opt == 'N' || opt == 'n') {
                        printf("You selected not to overwrite. Exiting.\n");
                        close(src_fd);
                        close(dest_fd);
                        return 0;
                    }
                }

                // Overwrite destination file
                close(dest_fd); 
                if (flag1 == 1) {
                    dest_fd = open(argv[argc - 1], O_TRUNC | O_WRONLY, var.st_mode);
                } else {
                    dest_fd = open(argv[argc - 1], O_TRUNC | O_WRONLY);
                }
                my_copy(src_fd, dest_fd);
            }

            close(src_fd);
            close(dest_fd);
        }
    } else {
        printf("Invalid arguments\nPass args: ./a.out <srcfile> <destfile>\n");
    }

    return 0;
}

